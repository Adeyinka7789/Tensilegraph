package tensionalsimulator;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.io.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.Timer;
import static tensionalsimulator.mainGui.area;

/**
 *
 * @author waheed
 */
public class tensionMachineV2 extends javax.swing.JFrame implements ActionListener {

    /**
     * Creates new form tensionMachine
     */
    Timer ti = new Timer(200,this);
    int x = 0, velx = 1;
    int mvx = 0;
    int decreaseHeight = 1;
    boolean start = true;
    public tensionMachineV2() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();

        setTitle("Tension Simulation Window™");
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setPreferredSize(new java.awt.Dimension(900, 700));
        setResizable(false);

        jButton1.setText("Stop");
        jButton1.setName("statbtn"); // NOI18N
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 344, Short.MAX_VALUE)
                .addComponent(jButton1))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jButton1)
                .addGap(0, 268, Short.MAX_VALUE))
        );

        jButton1.getAccessibleContext().setAccessibleName("statbtn");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        if(!start){ jButton1.setText("Stop"); ti.start(); }else{ jButton1.setText("Continue"); ti.stop(); }
        start = !start;
    }//GEN-LAST:event_jButton1ActionPerformed

    public String[] inputs;
    public double E, Load, diam, Length, UTS, yield, percMaxEx, LengthChange,
            lateralStrain, ChangeInDiam, maxload, maxChange, stress, strain,
            changingLoad, changingStress;
    double[] lengths;
    public String testSpecimen;
    boolean drawnStatic = false;
    int stopY;
    String[] retJa(){
        String[] k = Paramcalculator.nParams.split("-");
        try{
        /*FileReader fr = new FileReader("data.txt");        
        char [] a = new char[100];
        fr.read(a); // reads the content to the array
        int counter = 0;
        String charPart = "";
        for(char c : a)           
            if(c == '\n'){
                k[counter]= charPart;
                charPart = "";
                counter++;
            }
            else{
                //System.out.print(c);
                charPart = charPart+""+c;
            }
        fr.close();*/
        }
        catch(Exception e){
            k[0] = "";
            k[1] = "";
            k[2] = "";
            k[3] = "";
            k[4] = "";
            k[5] = "";
            k[6] = "";
            k[7] = "";
            k[8] = "";
            k[9] = "";
        }
        return k;
    }
    public void paint(Graphics g){
        super.paint(g);
        inputs = retJa();
        E = Double.parseDouble(inputs[0]);
        Load = Double.parseDouble(inputs[1]);
        diam = Double.parseDouble(inputs[2]);
        Length = Double.parseDouble(inputs[3]);
        UTS = Double.parseDouble(inputs[4]);
        yield = Double.parseDouble(inputs[6]);
        percMaxEx = Double.parseDouble(inputs[8]);
        testSpecimen = inputs[5];
        Paramcalculator calc = new Paramcalculator();
        maxChange = (percMaxEx/100)*Length;
        if(changingStress < UTS){
            stress = calc.Stress(Load, diam);
            strain = calc.LateralStrain(stress, E);
            lengths = calc.FinalLength(Length,strain, percMaxEx);
            LengthChange = calc.newLength(Length, stress, E, percMaxEx) - Length;        
            lateralStrain = calc.LateralStrain(stress, E);
            ChangeInDiam = calc.ChangeInDiameter(diam, lateralStrain, percMaxEx);
            area = calc.area(diam);
        }        
        maxload = calc.maxLoad(yield, area);
        stopY = Load > maxload? (int)Math.ceil((70*maxload)/maxload) : (int)Math.ceil((70*Load)/maxload);
        
        //The Legs where here        
        drawLegs(g);
        //The body
        specimen(g);
        drawBaseSkeleton(g);
        movableJaw(g);
        
        /*
        Calculations are updated here
        */
        changingLoad = (x*Load)/stopY;
        if(changingStress < UTS){            
            changingStress = calc.Stress(changingLoad, diam);
            strain = calc.LateralStrain(changingStress, E);
            lengths = calc.FinalLength(Length,strain, percMaxEx);
            lengths[0] = lengths[0]/10;
        }        
        
        //The strings was here
        drawStrings(g);
        if((changingStress >= UTS)){
           fail(g);
        }
        if(x < stopY){
            ti.start();
        }else{
            ti.stop();
        }
    }
    private void fail(Graphics g){
        Color c = new Color(240,240,240);
        g.setColor(c);
        /*g.fillRect(270, 440-20, 5, 20);
        g.fillRect(295, 440-20, 5, 20);*/
        g.drawLine(270, 450-20, 300, 450-20);
        g.fillArc((int)258, 420, 20, 20, -90, 180);
        g.fillArc((int)292, 420, 20, 20, 90, 180);
    }
    private void drawLegs(Graphics g){
        g.setColor(Color.darkGray);
        g.fillRect(5, 680, 890, 20); // Stand / Table
        g.fillOval(275, 660, 50, 50); // Left Oval Stand
        g.fillOval(575, 660, 50, 50); //Right Oval Stand
        g.fillRect(285, 640, 30, 50); //Left Rect Stand
        g.fillRect(585, 640, 30, 50); // Right  Rect Stand
    }
    
    private void drawBaseSkeleton(Graphics g){
        g.setColor(Color.darkGray);
        /*
        Element 1 is the Specimen holder
        */        
        g.fillRect(250, 550, 70, 100);
        g.setColor(Color.WHITE);
        g.drawOval(270, 560, 30, 30); //Specimen Holder
        /*
        Element 2 is Base
        */
        g.setColor(Color.darkGray);
        g.fillRect(250, 600, 400, 50);
        /*
        Right Retort
        */
        g.fillRect(550, 180, 100, 450);
        //Drawing Pattern on retort
        g.setColor(Color.white);
        g.drawLine(580, 200, 580, 450); //Horizontal
        g.drawLine(580, 200, 610, 200); //Top Vertical
        g.drawLine(580, 450, 610, 450); //Bottom Vertical
        /*
        Preparing the thread
        */
        int startX = 610;
        int startY = 200;
        int X = 20; //marks the difference in X
        int interval = 10; //Angle;
        for(int yref = 0; yref < 250; yref+=interval){
            g.drawLine(startX, startY + yref, startX-X, startY + yref + interval/2);
            g.drawLine(startX-X, startY + yref + interval/2, startX, startY + yref + interval);
        }
        
    }
    private void movableJaw(Graphics g){
        /*
        The Retort (Connects to the Thread)
        */
        int y = 270 - mvx;
        g.setColor(Color.darkGray);
        g.fillRect(250, y, 370, 50);
        g.setColor(Color.WHITE);
        g.drawOval(570, 275 - mvx, 40, 40); //movable knob
        g.fillRect(580, 285 - mvx, 20, 20);
        /*
        Hold the Specimen
        */
        g.setColor(Color.darkGray);
        g.fillRect(250, 270 - mvx, 70, 80);
        g.setColor(Color.WHITE);
        g.drawOval(270, 305 - mvx, 30, 30); //Specimen Holder
    }
    private void specimen(Graphics g){
        g.setColor(Color.BLUE);
        /*
        Holders (Big Ends)
        */
        g.fillRoundRect(260, 330 - mvx, 50, 40, 20, 20); //Upper Part
        g.fillRoundRect(260, 530, 50, 40, 20, 20); //Lower Part
        /*
        Specimen Shank / full body
        */
        g.fillRect(270, 340 - mvx, 30, 200 + mvx);
    }
    private void drawStrings(Graphics g){
        g.setColor(Color.RED);
        double percChange = (lengths[0]/Length)*100;//(maxLen < calc.newLength(Length, stress, E))? maxChange : maxLen - calc.newLength(Length, stress, E);
        percChange = (percChange > percMaxEx)? percMaxEx : percChange;        
        String stra = "Material: "+testSpecimen+" Load: "+Double.toString(Load)+"N";
        String strb = "Initial Diameter: "+Double.toString(diam)+"mm";
        String strc = "% Extension: "+Double.toString(percChange*1000)+"%";
        String strd = "Original Length: "+Double.toString(Length)+"mm Extension: "+
                lengths[0]*1000+"mm";
        String stre = "Load at this Point: "+Double.toString(changingLoad)+"N Stress at this point: "+
                Double.toString(changingStress);
        g.setFont(new Font("Consolas",Font.PLAIN,12));
        g.drawString(stra,50, 50);
        g.drawString(strb,50, 70);
        g.drawString(strc,50, 90);
        g.drawString(strd,50, 110);
        g.drawString(stre,50, 130);
    }

    public void actionPerformed(ActionEvent e){
        x = x + 1;
        if(changingStress < UTS){
            mvx++;
        }
        //decreaseHeight = ((x-500)%50 == 0)? decreaseHeight+ 1 : decreaseHeight+0;
        repaint();
    }
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(tensionMachineV2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(tensionMachineV2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(tensionMachineV2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(tensionMachineV2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new tensionMachineV2().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    // End of variables declaration//GEN-END:variables
}
