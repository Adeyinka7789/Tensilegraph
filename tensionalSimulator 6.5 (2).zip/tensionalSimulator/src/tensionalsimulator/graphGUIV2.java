/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 *
 */
package tensionalsimulator;
 
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import javax.swing.JOptionPane;
import java.awt.geom.AffineTransform;
import java.util.Scanner;
import javax.swing.Timer;

/**
 *
 * @author waheed
 */
public class graphGUIV2 extends javax.swing.JFrame implements ActionListener {

    /**
     * Creates new form graphGUI
     */
    public String[] inputs;
    double yeild, poisson, percMaxEx, Tstress, Tstrain, initl, maxlength, Chinl, ChinlB, E, ultstren;
    public static double maxLoad;
    Timer ti = new Timer(50, this);
    int x = 0, velx = 1;
    Boolean init = false;
    public graphGUIV2() {
        initComponents();
    }
    String[] retJa(){
        String[] k = Paramcalculator.nParams.split("-");
        try{
        /*FileReader fr = new FileReader("data.txt");        
        char [] a = new char[100];
        fr.read(a); // reads the content to the array
        int counter = 0;
        String charPart = "";
        for(char c : a)           
            if(c == '\n'){
                k[counter]= charPart;
                charPart = "";
                counter++;
            }
            else{
                charPart = charPart+""+c;
            }
        fr.close();*/
        }
        catch(Exception e){
            k[0] = "";
            k[1] = "";
            k[2] = "";
            k[3] = "";
            k[4] = "";
            k[5] = "";
            k[6] = "";
            k[7] = "";
            k[8] = "";
            k[9] = "";
        }
        return k;
    }
    String sortString(String str){
        int i = str.length();
        int start = 0;
        String nstr;
        if(str.contains("E")){
            int cat = str.indexOf("E");
            nstr = str.substring(0,4)+""+str.substring(cat,i);
        }
        else if(i < 4){
            nstr = str;
        }
        else{
            //int dotStand = str.indexOf(".");
            if(i < 6 ){
                nstr = str.substring(0,i);
            }else{
                nstr = str.substring(0,6);
            }
        }
        return nstr;
    }
    public void paint(Graphics g){        
        inputs = retJa();
        if(!init){ createAxes(g);}
        Paramcalculator c = new Paramcalculator();
        initl = Double.parseDouble(inputs[3]);
        yeild = Double.parseDouble(inputs[6]);
        poisson = Double.parseDouble(inputs[7]);
        percMaxEx = Double.parseDouble(inputs[8]);
        E = Double.parseDouble(inputs[0]);
        Tstress = c.Stress(Double.parseDouble(inputs[1]), Double.parseDouble(inputs[2]));
        Tstrain = c.LateralStrain(Tstress, Double.parseDouble(inputs[0]));       
        maxlength = (percMaxEx/100)*initl + initl;
        ultstren = Double.parseDouble(inputs[4]);
        //Program plots the graph
        plotLoad(g);
        plotStress(g);
        if(x < 400){
            ti.start();
        }else{
            ti.stop();
        }
        if(!init){ setLegend(g); init = true;}
    }
    private void plotStress(Graphics g){
        int startPixel;
        boolean drawnmarker = false;
        boolean reach = false;
        Paramcalculator c = new Paramcalculator();
        //while(t <= 400){
        if(true){
            startPixel = x;
            if (reach){
                g.setColor(Color.red);
            }else{
                g.setColor(Color.BLUE);
            }
            //this is new 
            double pstrain = (Tstrain*startPixel)/400;
            double pstress = pstrain*Double.parseDouble(inputs[0])*1;
            if(pstress >= yeild){
                pstress = (1-poisson)*yeild + poisson*Double.parseDouble(inputs[0])*pstrain*1;
                reach = true;
            }
            Double xpixel = Math.ceil((pstress*400)/Tstress);            
            if(pstress <= ultstren){//!drawnmarker && pstress >= yeild){
                ChinlB = c.newLength(initl, pstress, E, maxlength);
                g.drawLine(50+startPixel, 500-xpixel.intValue(), 50+startPixel, 500-xpixel.intValue());
                g.setColor(Color.black);
                g.drawOval(50+startPixel-5, 500-xpixel.intValue(), 5, 5);
                g.fillOval(50+startPixel-5, 500-xpixel.intValue()+3, 2, 2);
                //drawnmarker = true;
            }else{
                
            }
            if((startPixel%50) == 0){
                g.setColor(new Color(241,240,240));
                Double _temp =  ((double)startPixel/(double)400)*Tstress;
                String pstrstr = Double.toString(_temp);
                String strstrval = Double.toString(pstrain);
                g.setColor(Color.black);
                g.drawString(sortString(pstrstr),8, 500-startPixel);
                g.drawString(sortString(strstrval),startPixel+40, 520);
            }
            //startPixel++;
        }
    }
    private void plotLoad(Graphics g){
        Paramcalculator c = new Paramcalculator();
        double loadMax = Double.parseDouble(inputs[1])*0.43;
        Tstress = c.Stress(Double.parseDouble(inputs[1]), Double.parseDouble(inputs[2]));
        double maxextension;// = c.newLength(Double.parseDouble(inputs[3]), Tstress,Double.parseDouble(inputs[0]), Double.parseDouble(inputs[8])) - Double.parseDouble(inputs[3]);
        maxextension = initl*(percMaxEx/100);//(maxextension > exLim)? exLim : maxextension;
        int t;
        //while(t <= 400){
        if(true){
            t = x;
            double Nload = (t*(loadMax))/400;
            double Gstress = c.Stress(Nload, Double.parseDouble(inputs[2]));
            Tstrain = c.LateralStrain(Gstress, Double.parseDouble(inputs[0]));
            Double xp;
            if(Gstress >= yeild){
                 Tstress = (1-poisson)*yeild + poisson*Double.parseDouble(inputs[0])*Tstrain*1;
                if(Gstress <= ultstren){
                    Chinl = c.newLength(Double.parseDouble(inputs[3]), Tstress,Double.parseDouble(inputs[0]), Double.parseDouble(inputs[8])) - Double.parseDouble(inputs[3]);
                    //xp = Math.ceil((Chinl*400)/maxextension);                    
                }
                xp = Math.ceil((Chinl*400)/maxextension);
                g.setColor(Color.red);                
            }else{
                g.setColor(Color.GREEN);
                Tstress = Gstress;
                if(true){
                    Chinl = c.newLength(Double.parseDouble(inputs[3]), Tstress,Double.parseDouble(inputs[0]), Double.parseDouble(inputs[8])) - Double.parseDouble(inputs[3]);
                }
                xp = Math.ceil((Chinl*400)/maxextension);                
            }
            if(Gstress <= ultstren){//!drawnmarker && pstress >= yeild){
                g.setColor(Color.black);
                g.drawOval(650+xp.intValue(), 500-t-5, 5, 5);
                g.fillOval(650+xp.intValue()+3, 500-t-5, 2, 2);
                g.drawLine(650+xp.intValue(), 500-t, 650+xp.intValue(), 500-t);
                //drawnmarker = true;
            }
            double chart = ((t/40)*maxextension)/10;
            if((t%50) == 0){
                g.setColor(new Color(241,240,240));
                //g.drawLine(50, 500-startPixel, 450, 500-startPixel);
                String pstrstr = Double.toString(Nload);
                String strstrval = Double.toString(chart);
                g.setColor(Color.black);
                g.drawString(sortString(strstrval),  635+t, 520);
                g.drawString(sortString(pstrstr), 650-40, 500-t);
            }
            //t++;
        }   
    }
    private void setLegend(Graphics g){
        g.setColor(Color.red);
        Graphics2D g2d = (Graphics2D)g;
        AffineTransform at = new AffineTransform();
        at.setToRotation(Math.PI/2);
        g2d.setTransform(at);
        g2d.drawString("Stress N/mm^2", 280, -460);
        at.setToRotation(-Math.PI/2);
        g2d.setTransform(at);
        g2d.drawString("Load N", -350, 600);
    }
    private void createAxes(Graphics g){        
        Graphics2D g2d = (Graphics2D)g;
        
        /*
        Fills the stage with a color. Transparent Background is undesirable
        */
        g.setColor(new Color(241,240,240));
        g.fillRect(0, 0, 1200, 600);
        g.setColor(Color.BLACK);
        
        /*
        Paints the graph area in white. Makes sense to show the faint grid
        */
        g.setColor(Color.WHITE);
        g.fillRect(50,100,400,400);
        g.fillRect(650,100,400,400);
        g.setColor(Color.BLACK);
        
        /*
        Helps us create the grids
        */
        int iol = 0;
        while(iol <= 400){
            g.setColor(Color.black);
            g.drawLine(iol, 500, iol, 490);
            g.setColor(new Color(241,240,240));
            g.drawLine(iol, 490, iol, 100);
            //horizontal
            g.setColor(new Color(241,240,240));
            g.drawLine(50, 100+iol, 450, 100+iol);
            g.setColor(Color.black);
            g.drawLine(50, 100+iol, 60, 100+iol);            
            iol = iol +50;
        }
        
        // Replicating on graph 2
        iol = 0;
        while(iol <= 400){
            g.setColor(Color.black);
            g.drawLine(650+iol, 500, 650+iol, 490);
            g.setColor(new Color(241,240,240));
            g.drawLine(650+iol, 490, 650+iol, 100);
            //horizontal
            g.setColor(new Color(241,240,240));
            g.drawLine(650, iol+100, 1050, iol+100);
            g.setColor(Color.black);
            g.drawLine(650, iol+100, 660, iol+100);
            iol = iol +50;
        }
        
        /*
        Tracing out the axes
        */
        g.setColor(Color.BLACK);        
        g.drawLine(50,100,50,500);
        g.drawLine(50, 500, 450, 500);
        g.drawLine(650,100,650,500);
        g.drawLine(650, 500, 1050, 500);
        
        /*
        Sets the Title of the graph and the legend
        */
        g.setFont(new Font("TimesRoman",Font.PLAIN,18));
        g.drawString("The Stress-Strain Graph for "+inputs[5],50, 50);
        g.drawString("The Load-Extension Graph for "+inputs[5],650, 50);
        g.setFont(new Font("Consolas",Font.PLAIN,10));
        g.setColor(Color.white);
        
        //setting the axis names        
        g.setFont(new Font("Cambria",Font.PLAIN,12));
        g.setColor(Color.red);
        g.drawString("Strain", 200, 540);
        g.drawString("Extension mm", 800, 540);        
    }
    
    public void actionPerformed(ActionEvent e){
        x = x + 1;
        //decreaseHeight = ((x-500)%50 == 0)? decreaseHeight+ 1 : decreaseHeight+0;
        repaint();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setTitle("THE GRAPHS");
        setBackground(new java.awt.Color(241, 240, 240));
        setPreferredSize(new java.awt.Dimension(600, 600));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 750, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 472, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(graphGUIV2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(graphGUIV2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(graphGUIV2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(graphGUIV2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new graphGUIV2().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
