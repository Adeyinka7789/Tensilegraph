/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package tensionalsimulator;
import java.io.*;
/**
 *
 * @author waheed
 */
public class Paramcalculator {
    double pii = 3.142;
    public static String nParams;
    double Stress(double force, double diameter){
        double stressValue = force/area(diameter);
        return stressValue;
    }
    double ChangeInDiameter(double Odiameter, double lateralStrain, double maxEx){
        double diameterValue = (maxEx == 0)? -0 : -(Odiameter*lateralStrain);
        return diameterValue;
    }
    double Force(double stress, double diameter){
        double forceValue = stress*area(diameter);
        return forceValue;
    }
    double LateralStrain(double stress, double E){
        double vi = stress/(E*1);
        return vi;
    }
    double axialStrain(double lateralStrain, double poisson){
        double v = lateralStrain/poisson;
        return v;
    }
    double[] FinalLength(double Olength, double strain, double Maxper){
        double[] outs = new double[3];
        double changeinlength = (strain*Olength);
        outs[0] = changeinlength;
        outs[1] = (Maxper==0)? Olength : changeinlength + Olength;
        outs[2] = (changeinlength/Olength)*100;
        return outs;
    }
    double maxLoad(double yield, double area){
        double maxl = yield*area;
        return maxl;
    }
    double maximumLength(double Olength, double yield, double E){
        //double finalLen = Olength*(1+(yield/(E*1)));
        double finalLen = Olength*(1+(yield/(E*1)));
        return finalLen;
    }
    double newLength(double Olength, double stress, double E, double Maxlen){
        //double finalLen = (Maxlen==0)? Olength : Olength*(1+(stress/(E*1)));
        double finalLen = (Maxlen==0)? Olength : Olength + ((Olength*stress)/(E*1))*100;
        return finalLen;
    }
    double area(double diam){
        double reArea = pii*(Math.pow(diam/2, 2)); //(pii/4)*diam*diam;
        return reArea;
    }
    double surfaceRed(double L, double D, double nL){
        double ORVol = 2*pii*(D/2)*L;
        double r = ORVol/(2*pii*nL);
        return 2*r;
    }
    String Shortener(double num, String Unit){
        String[] lead = {"0.0","0.00","0.000","0.0000","0.00000","0.000000","0.0000000"};
        String batch = "";
        String number = Double.toString(num);
        int numlent = number.length();
        int PeriodIndex;
        int power;
        int Eplace;
        if(number.contains("E")){
            Eplace = number.indexOf("E");
            power = (int)Double.parseDouble(number.substring(Eplace+1));
        }else{
            power = 1;
            Eplace = numlent-1;
        }
        if(number.contains(".")){
            PeriodIndex = number.indexOf(".");
        }else{
            PeriodIndex = numlent;
        }
        String newNumber = number.substring(0,Eplace-1);
        if(PeriodIndex == numlent){
            //if()
            batch = number+" "+Unit;
        }else{
            if(power == 6){
                batch = newNumber.substring(0,PeriodIndex)+" M"+Unit;
            }else if(power > 6){
                batch = newNumber.substring(0,PeriodIndex)+""+newNumber.substring(PeriodIndex+1, PeriodIndex+1+(power-6))+" M"+Unit;
            }else if (power < 6 && power > 1){
                int leading = 6-power-PeriodIndex;
                if(leading >= 0){
                    batch = lead[leading]+""+newNumber.substring(0, PeriodIndex)+""+newNumber.substring(PeriodIndex+1, PeriodIndex+1+2)+" M"+Unit;
                }else{
                    leading = -leading;
                    batch = newNumber.substring(0,PeriodIndex-leading)+"."+newNumber.substring(PeriodIndex-leading, PeriodIndex+1)+" M"+Unit;
                }
            }else{
                batch = number.substring(0, PeriodIndex)+"."+number.substring(PeriodIndex+1, PeriodIndex+2)+" "+Unit;
            }
        }
        return batch;
    }
    void filewriter(double E, double F, double Diam, double initl, double ultstress,
            String someString, double yield, double poisson, double maxEx) throws IOException{
         //File file = new File("data.txt");       // creates the file       
         //file.createNewFile();       // creates a FileWriter Object       
         //FileWriter writer = new FileWriter(file);        // Writes the content to the file       
         //writer.write(Double.toString(E)+"\n"+Double.toString(F)+"\n"+Double.toString(Diam)+"\n"+Double.toString(initl)+"\n"+Double.toString(ultstress)+"\n"+someString+"\n"+Double.toString(yield)+"\n"+Double.toString(poisson)+                 "\n"+Double.toString(maxEx)+"\nPlaceholder");
         nParams = Double.toString(E)+"-"+Double.toString(F)+"-"+Double.toString(Diam)+"-"+Double.toString(initl)+
                 "-"+Double.toString(ultstress)+"-"+someString+"-"+Double.toString(yield)+"-"+Double.toString(poisson)+
                 "-"+Double.toString(maxEx)+"-Placeholder";
         //writer.flush();       
         //writer.close();
    }
}
